import libreelec

timeout = None
date_fmt = '%d %b %y'
arch = libreelec.OS_RELEASE.get('LIBREELEC_ARCH')
