from ..utils import bitly, xbmcutil
from . import veetle, sopcast
import urllib2, re, xbmc, platform

try :
    import html
except :
    import HTMLParser
    html = HTMLParser.HTMLParser()

sourceSite='http://www.sport365.live/'
# Dutch
mainList = '/en/events/-/1/-/17/60'
# Global
#mainList = '/en/events/-/1/-/-'

regexpr = '<tr(.*?)event_([a-fA-F0-9]*)(.*?)><td(.*?)><\/td><td(.*?)><img(.*?)src="(.*?)" \/><\/td><td rowspan=2 style="width: 40px;">(([0-9]*):([0-9]*))<\/td><td(.*?)>(.*?)<\/td><td(.*?)>(.*?)<\/td>(.*?)<\/tr><tr'

try :
    custom_ua = xbmc.getInfoLabel("System.FriendlyName")[:4] + "/" + xbmc.getInfoLabel("System.BuildVersion")[:4]+" ("+platform.system()+" "+platform.release() +")"
except:
    custom_ua = bitly.getUserAgent()

def addStreams():
    pBar = xbmcutil.createProgressBar('NL Sports', 'Laden van streams...')
    url = sourceSite + mainList;
    userAgent = custom_ua
    page = bitly.getPage(sourceSite + mainList, sourceSite, userAgent)
    
    #regTableRow = re.compile(regexpr, re.DOTALL)
    #matches = regTableRow.findall(page)
    reg="images\/types.*?(green|red).*?px;\">(.*?)<\/td><td style=\"borde.*?>(.*?)<\/td><td.*?>(.*?)<\/td.*?showDivLink.*?\"(\/en\/links.*?)\".*?\">(.*?)<"
    sportslinks=re.findall(reg,page)
    if len(sportslinks) > 0 :
        percentage = 0
        percUpdate = 100 / len(sportslinks)
    else :
        percentage = 99
        percUpdate = 1

    for color,time,name,lang,link,cat in sportslinks:
        percentage = percentage + percUpdate
        xbmcutil.updateProgressBar(pBar, percentage, 'Bezig met laden...')
        #tp = 'green', 
        #tm = '18:00', 
        #nm = 'Sporting Braga - FC Sion', 
        #lng ='<span style="color:#FF6600">HQ&nbsp;</span>Dutch', 
        #lnk = '/en/links/56cd853720d2e769889318/1', 
        #cat = 'Soccer / UEFA - Europa League'
        if color == "green":
            streams = findStreams(link)
            for streamUrl in streams :
                xbmcutil.addMenuItem('[COLOR '+color+']'+time +" - "+ name +'[/COLOR]', streamUrl, 'true', 'bvls','bvls')
    xbmcutil.endOfList()

def findStreams(page) :
    #page = "/en/links/"+id+"/1"
    userAgent = custom_ua
    content = bitly.getPage(sourceSite + page, sourceSite, userAgent)
    regLinks = re.compile("(.*?)window\.open\('(.*?)',(.*?)\)",re.DOTALL)
    links = regLinks.findall(content)
    link_array = []
    for l in links:
        #p = bitly.getPage(l[1], sourceSite, userAgent)
        p = getUrl(l[1])
        iframe_src = resolveIframe(p)
        stream_link = findStream(iframe_src)
        link_array.append(stream_link)
        
    return link_array
    

def getUrl(url, cookieJar=None,post=None, timeout=20, headers=None):
    cookie_handler = urllib2.HTTPCookieProcessor(cookieJar)
    opener = urllib2.build_opener(cookie_handler, urllib2.HTTPBasicAuthHandler(), urllib2.HTTPHandler())
    #opener = urllib2.install_opener(opener)
    req = urllib2.Request(url)
    req.add_header('User-Agent',custom_ua)
    if headers:
        for h,hv in headers:
            req.add_header(h,hv)

    response = opener.open(req,post,timeout=timeout)
    link=response.read()
    response.close()
    return link;

def findStream(iframe_src) :
    iframe_content = getUrl(html.unescape(iframe_src))
    reg='name="f" value="(.*?)"'
    enclink=re.findall(reg,iframe_content)[0]  
    reg='name="s" value="(.*?)"'
    encst=re.findall(reg,iframe_content)[0]
    
    decodedst=decode(encst)
    reg='"stkey":"(.*?)"'
    sitekey=re.findall(reg,decodedst)[0]
    
    urlToPlay= decode(enclink.replace(sitekey,""))+"|Referer=http://h5.adshell.net/flash&User-Agent="+custom_ua
    return urlToPlay
    

def resolveIframe(content) :
    regIframe = re.compile('document\.write\(\'<iframe(.*?)src="(.*?)"(.*?)>(.*?)<\/iframe>\'\);', re.DOTALL)
    iframesrc = regIframe.search(content).group(2)
    return iframesrc
    
##
# FROM DSS
#
# Thanks to those guys!
##
import re
def tr(param1 , param2 , param3):
    _loc4_ = 0;
    _loc5_= "";
    _loc6_ = None
    if( ord(param1[- 2]) == param2 and ord(param1[2]) == param3):
        _loc5_ = "";
        _loc4_ = len(param1)- 1;
        while(_loc4_ >= 0):
            _loc5_ = _loc5_ + param1[_loc4_]
            _loc4_-=1;
        param1 = _loc5_;
        _loc6_ = int(param1[-2:]);
        print 'xx',_loc6_
        param1 = param1[2:];
        param1 = param1[0:-3];
        _loc6_ = _loc6_ / 2;
        if(_loc6_ < len(param1)):
            _loc4_ = _loc6_;
        while(_loc4_ < len(param1)):
            param1 = param1[0:_loc4_]+ param1[_loc4_ + 1:]
            _loc4_ = _loc4_ + _loc6_ * 1;

        param1 = param1 + "!";

    return param1;

def swapme(st, fromstr , tostr):
    st=st.replace(tostr,"___")
    st=st.replace(fromstr,tostr)
    st=st.replace("___", fromstr)
    return st

     
def decode(encstring):
    encstring=tr(encstring ,114,65)
    mc_from="MD7cXIZxt5B61RHbN8dovGzW3C"
    mc_to="myilk4UpJfYLgn0u9eQwsVaT2="
    if 1==2:#encstring.endswith("!"):
        encstring=encstring[:-1]
        mc_from="ngU08IuldVHosTmZz9kYL2bayE"
        mc_to="v7ec41D6GpBtXx3QJRiN5WwMf="

    st=encstring
    for i in range(0,len(mc_from)):
        st=swapme(st, mc_from[i], mc_to[i])
    return st.decode("base64")
