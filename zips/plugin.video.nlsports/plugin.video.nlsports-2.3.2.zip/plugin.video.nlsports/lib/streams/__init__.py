__all__ = ["ads","bvls","ctv","dazsports","dscplus","iptv", "janlul","lmmg","mdhzk", "pole", "sotd", "spst", "sport365", "sopcast","stv","veetle"]
