===========================
Specto fork of EPiC GENESiS
===========================

About
-----
Mrknow's *fork* of GENESiS


About
-----
The origins of streaming


Attributions
---------------------
- 4orbs theme by Marquerite 
- Clean theme by jokster 
- Embossed theme by jokster  
- GOne theme by jokster 
- Metro theme by rayw1986 


MO' iNFO:
------------------------
Specto v2016.03.06.xvbmc
------------------------
+ an EPiC XvBMC *FORK* 2 replace old Lambda's GENESiS! 
+ You should use Salts HD Lite by now  ;-)  :-P  3:) ! 
 
+ Trakt + RealDebrid *UNDER CONSTRUCTION* 
+ see: http://filmkodi.com/en/fork-of-genesis/#comment-355 
------------------------
Specto v2016.03.06.xvbmc
------------------------


License
-------
This software is released under the [GPL 3.0 license] [1].
[1]: http://www.gnu.org/licenses/gpl-3.0.html