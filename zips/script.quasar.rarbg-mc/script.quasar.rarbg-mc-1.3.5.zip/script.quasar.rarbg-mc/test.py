# coding: utf-8
__author__ = 'mancuniancol'

data = '''

<!DOCTYPE html>
<html lang="en">
<head>
<title>The Pirate Bay - The galaxy's most resilient bittorrent site</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<meta name="google-site-verification" content=""/>
<link rel="search" type="application/opensearchdescription+xml" href="/opensearch.xml" title="Search The Pirate Bay"/>
<link rel="stylesheet" type="text/css" href="https://thepiratebay.rs/css/pirate6.css"/>
<link rel="dns-prefetch" href="//syndication.exoclick.com/">
<link rel="dns-prefetch" href="//main.exoclick.com/">
<link rel="dns-prefetch" href="//static-ssl.exoclick.com/">
<link rel="dns-prefetch" href="//ads.exoclick.com/">
<link rel="canonical" href="https://thepiratebay.rs/search/supernatural-s11e12/0/99/200"/>
<style type="text/css">.searchBox{margin:6px;width:300px;vertical-align:middle;padding:2px;background-image:url('https://thepiratebay.rs/static/img/icon-http.gif');background-repeat:no-repeat;background-position:right;}.detLink{font-size:1.2em;font-weight:400;}.detDesc{color:#4e5456;}.detDesc a:hover{color:#000099;text-decoration:underline;}.sortby{text-align:left;float:left;}.detName{padding-top:3px;padding-bottom:2px;}.viewswitch{font-style:normal;float:right;text-align:right;font-weight:normal;}</style>
<meta name="description" content="Search for and download any torrent from the pirate bay using search query supernatural s11e12. Direct download via magnet link."/>
<meta name="keywords" content="supernatural s11e12 direct download torrent magnet tpb piratebay search"/>

<script type="text/javascript">
  var _pop = _pop || [];
  _pop.push(['siteId', 1003349]);
  _pop.push(['minBid', 0.000000]);
  _pop.push(['popundersPerIP', 0]);
  _pop.push(['delayBetween', 0]);
  _pop.push(['default', false]);
  _pop.push(['defaultPerDay', 0]);
  _pop.push(['topmostLayer', false]);
  (function() {
    var pa = document.createElement('script'); pa.type = 'text/javascript'; pa.async = true;
    var s = document.getElementsByTagName('script')[0];
    pa.src = '//c1.popads.net/pop.js';
    pa.onerror = function() {
      var sa = document.createElement('script'); sa.type = 'text/javascript'; sa.async = true;
      sa.src = '//c2.popads.net/pop.js';
      s.parentNode.insertBefore(sa, s);
    };
    s.parentNode.insertBefore(pa, s);
  })();
</script>

<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-71596015-1', 'auto');
  ga('send', 'pageview');

</script> </head>
<body>
<div id="header">
<form method="get" id="q" action="/search.php">
<a href="/" class="img"><img src="https://thepiratebay.rs/static/img/tpblogo_sm_ny.gif" id="TPBlogo" alt="The Pirate Bay"/></a>
<b><a href="/" title="Search Torrents">Search Torrents</a></b>&nbsp;&nbsp;|&nbsp;
<a href="/browse" title="Browse Torrents">Browse Torrents</a>&nbsp;&nbsp;|&nbsp;
<a href="/recent" title="Recent Torrent">Recent Torrents</a>&nbsp;&nbsp;|&nbsp;
<a href="/tv/" title="TV shows">TV shows</a>&nbsp;&nbsp;|&nbsp;
<a href="/music" title="Music">Music</a>&nbsp;&nbsp;|&nbsp;
<a href="/top" title="Top 100">Top 100</a>
<br/><input type="search" class="inputbox" title="Pirate Search" name="q" placeholder="Search here..." value="supernatural s11e12"/><input value="Pirate Search" type="submit" class="submitbutton"/><br/> <label for="audio" title="Audio"><input id="audio" name="audio" onclick="javascript:rmAll();" type="checkbox"/>Audio</label>
<label for="video" title="Video"><input id="video" name="video" onclick="javascript:rmAll();" type="checkbox" checked="checked"/>Video</label>
<label for="apps" title="Applications"><input id="apps" name="apps" onclick="javascript:rmAll();" type="checkbox"/>Applications</label>
<label for="games" title="Games"><input id="games" name="games" onclick="javascript:rmAll();" type="checkbox"/>Games</label>
<label for="porn" title="Porn"><input id="porn" name="porn" onclick="javascript:rmAll();" type="checkbox"/>Porn</label>
<label for="other" title="Other"><input id="other" name="other" onclick="javascript:rmAll();" type="checkbox"/>Other</label>
<select id="category" name="category" onchange="javascript:setAll();">
<option value="0">All</option>
<optgroup label="Audio">
<option value="101">Music</option>
<option value="102">Audio books</option>
<option value="103">Sound clips</option>
<option value="104">FLAC</option>
<option value="199">Other</option>
</optgroup>
<optgroup label="Video">
<option value="201">Movies</option>
<option value="202">Movies DVDR</option>
<option value="203">Music videos</option>
<option value="204">Movie clips</option>
<option value="205">TV shows</option>
<option value="206">Handheld</option>
<option value="207">HD - Movies</option>
<option value="208">HD - TV shows</option>
<option value="209">3D</option>
<option value="299">Other</option>
</optgroup>
<optgroup label="Applications">
<option value="301">Windows</option>
<option value="302">Mac</option>
<option value="303">UNIX</option>
<option value="304">Handheld</option>
<option value="305">IOS (iPad/iPhone)</option>
<option value="306">Android</option>
<option value="399">Other OS</option>
</optgroup>
<optgroup label="Games">
<option value="401">PC</option>
<option value="402">Mac</option>
<option value="403">PSx</option>
<option value="404">XBOX360</option>
<option value="405">Wii</option>
<option value="406">Handheld</option>
<option value="407">IOS (iPad/iPhone)</option>
<option value="408">Android</option>
<option value="499">Other</option>
</optgroup>
<optgroup label="Porn">
<option value="501">Movies</option>
<option value="502">Movies DVDR</option>
<option value="503">Pictures</option>
<option value="504">Games</option>
<option value="505">HD - Movies</option>
<option value="506">Movie clips</option>
<option value="599">Other</option>
</optgroup>
<optgroup label="Other">
<option value="601">E-books</option>
<option value="602">Comics</option>
<option value="603">Pictures</option>
<option value="604">Covers</option>
<option value="605">Physibles</option>
<option value="699">Other</option>
</optgroup>
</select>
<input type="hidden" name="page" value="0"/>
<input type="hidden" name="orderby" value="99"/>
</form>
</div>
<h2><span>Search results: supernatural s11e12</span>&nbsp;Displaying hits from 0 to 8 (approx 8 found)</h2>
<div id="SearchResults"><div id="content">
<div id="sky-right">
</div>
<div id="main-content">
<table id="searchResult">
<thead id="tableHead">
<tr class="header">
<th><a href="/search/supernatural-s11e12/0/13/200" title="Order by Type">Type</a></th>
<th><div class="sortby"><a href="/search/supernatural-s11e12/0/1/200" title="Order by Name">Name</a> (Order by: <a href="/search/supernatural-s11e12/0/3/200" title="Order by Uploaded">Uploaded</a>, <a href="/search/supernatural-s11e12/0/5/200" title="Order by Size">Size</a>, <span style="white-space: nowrap;"><a href="/search/supernatural-s11e12/0/11/200" title="Order by ULed by">ULed by</a></span>, <a href="/search/supernatural-s11e12/0/8/200" title="Order by Seeders">SE</a>, <a href="/search/supernatural-s11e12/0/9/200" title="Order by Leechers">LE</a>)</div><div class="viewswitch"> View: <a href="#" onClick="alert('This feature is not yet supported. I need to spend a long time adding support for cookies, if/when I do this feature will work.')">Single</a> / Double&nbsp;</div></th>
<th><abbr title="Seeders"><a href="/search/supernatural-s11e12/0/8/200" title="Order by Seeders">SE</a></abbr></th>
<th><abbr title="Leechers"><a href="/search/supernatural-s11e12/0/9/200" title="Order by Leechers">LE</a></abbr></th>
</tr>
</thead>
<tr>
<td class="vertTh">
<center>
<a href="/browse/200" title="More from this category">Video</a><br/>
(<a href="/browse/205" title="More from this category">TV shows</a>)
</center>
</td>
<td>
<div class="detName"> <a href="/torrent/13422424/Supernatural.S11E12.HDTV.x264-LOL[ettv]" class="detLink" title="Details for Supernatural.S11E12.HDTV.x264-LOL[ettv]">Supernatural.S11E12.HDTV.x264-LOL[ettv]</a>
</div>
<a href="magnet:?xt=urn:btih:5d202f5b7cff4d3157535951ef19282962d75659&dn=Supernatural.S11E12.HDTV.x264-LOL%5Bettv%5D&tr=udp%3A//tracker.openbittorrent.com%3A80&tr=udp%3A//open.demonii.com%3A1337&tr=udp%3A//tracker.coppersurfer.tk%3A6969&tr=udp%3A//exodus.desync.com%3A6969" title="Download this torrent using magnet"><img src="https://thepiratebay.rs/static/img/icon-magnet.gif" alt="Magnet link"/></a><a href="/tt.php?tor=bWFnbmV0Oj94dD11cm46YnRpaDo1ZDIwMmY1YjdjZmY0ZDMxNTc1MzU5NTFlZjE5MjgyOTYyZDc1NjU5JmRuPVN1cGVybmF0dXJhbC5TMTFFMTIuSERUVi54MjY0LUxPTCU1QmV0dHYlNUQmdHI9dWRwJTNBJTJGJTJGdHJhY2tlci5vcGVuYml0dG9ycmVudC5jb20lM0E4MCZ0cj11ZHAlM0ElMkYlMkZvcGVuLmRlbW9uaWkuY29tJTNBMTMzNyZ0cj11ZHAlM0ElMkYlMkZ0cmFja2VyLmNvcHBlcnN1cmZlci50ayUzQTY5NjkmdHI9dWRwJTNBJTJGJTJGZXhvZHVzLmRlc3luYy5jb20lM0E2OTY5&t=Supernatural.S11E12.HDTV.x264-LOL[ettv]&i=" target="_blank" title="Stream using Torrents-Time (Beta)"><img src="https://thepiratebay.rs/static/img/icons/icon-tt.png" alt="Stream link"/></a><img src="https://thepiratebay.rs/static/img/icon_comment.gif" alt="This torrent has 4 comments." title="This torrent has 4 comments."/><a href="/user/ettv"><img src="https://thepiratebay.rs/static/img/vip.gif" alt="VIP" title="VIP" style="width:11px;" border='0'/></a>
<font class="detDesc">Uploaded 02-04&nbsp;04:04, Size 234.47&nbsp;MiB, ULed by <a class="detDesc" href="/user/ettv/" title="Browse ettv">ettv</a></font>
</td>
<td align="right">5893</td>
<td align="right">688</td>
</tr>
<tr class="alt">
<td class="vertTh">
<center>
<a href="/browse/200" title="More from this category">Video</a><br/>
(<a href="/browse/208" title="More from this category">HD - TV shows</a>)
</center>
</td>
<td>
<div class="detName"> <a href="/torrent/13422422/Supernatural.S11E12.720p.HDTV.X264-DIMENSION[ettv]" class="detLink" title="Details for Supernatural.S11E12.720p.HDTV.X264-DIMENSION[ettv]">Supernatural.S11E12.720p.HDTV.X264-DIMENSION[ettv]</a>
</div>
<a href="magnet:?xt=urn:btih:a18db4afb4bb0dd94ef15c76756918326b07685e&dn=Supernatural.S11E12.720p.HDTV.X264-DIMENSION%5Bettv%5D&tr=udp%3A//tracker.openbittorrent.com%3A80&tr=udp%3A//open.demonii.com%3A1337&tr=udp%3A//tracker.coppersurfer.tk%3A6969&tr=udp%3A//exodus.desync.com%3A6969" title="Download this torrent using magnet"><img src="https://thepiratebay.rs/static/img/icon-magnet.gif" alt="Magnet link"/></a><a href="/tt.php?tor=bWFnbmV0Oj94dD11cm46YnRpaDphMThkYjRhZmI0YmIwZGQ5NGVmMTVjNzY3NTY5MTgzMjZiMDc2ODVlJmRuPVN1cGVybmF0dXJhbC5TMTFFMTIuNzIwcC5IRFRWLlgyNjQtRElNRU5TSU9OJTVCZXR0diU1RCZ0cj11ZHAlM0ElMkYlMkZ0cmFja2VyLm9wZW5iaXR0b3JyZW50LmNvbSUzQTgwJnRyPXVkcCUzQSUyRiUyRm9wZW4uZGVtb25paS5jb20lM0ExMzM3JnRyPXVkcCUzQSUyRiUyRnRyYWNrZXIuY29wcGVyc3VyZmVyLnRrJTNBNjk2OSZ0cj11ZHAlM0ElMkYlMkZleG9kdXMuZGVzeW5jLmNvbSUzQTY5Njk=&t=Supernatural.S11E12.720p.HDTV.X264-DIMENSION[ettv]&i=" target="_blank" title="Stream using Torrents-Time (Beta)"><img src="https://thepiratebay.rs/static/img/icons/icon-tt.png" alt="Stream link"/></a><a href="/user/EtHD"><img src="https://thepiratebay.rs/static/img/vip.gif" alt="VIP" title="VIP" style="width:11px;" border='0'/></a><img src="https://thepiratebay.rs/static/img/11x11p.png"/>
<font class="detDesc">Uploaded 02-04&nbsp;04:02, Size 658.91&nbsp;MiB, ULed by <a class="detDesc" href="/user/EtHD/" title="Browse EtHD">EtHD</a></font>
</td>
<td align="right">260</td>
<td align="right">15</td>
</tr>
<tr>
<td class="vertTh">
<center>
<a href="/browse/200" title="More from this category">Video</a><br/>
(<a href="/browse/205" title="More from this category">TV shows</a>)
</center>
</td>
<td>
<div class="detName"> <a href="/torrent/13422459/Supernatural.S11E12.HDTV.XviD-FUM[ettv]" class="detLink" title="Details for Supernatural.S11E12.HDTV.XviD-FUM[ettv]">Supernatural.S11E12.HDTV.XviD-FUM[ettv]</a>
</div>
<a href="magnet:?xt=urn:btih:b5f9efe7cd948ab1d7756277e44b6fe15e72cc8b&dn=Supernatural.S11E12.HDTV.XviD-FUM%5Bettv%5D&tr=udp%3A//tracker.openbittorrent.com%3A80&tr=udp%3A//open.demonii.com%3A1337&tr=udp%3A//tracker.coppersurfer.tk%3A6969&tr=udp%3A//exodus.desync.com%3A6969" title="Download this torrent using magnet"><img src="https://thepiratebay.rs/static/img/icon-magnet.gif" alt="Magnet link"/></a><a href="/tt.php?tor=bWFnbmV0Oj94dD11cm46YnRpaDpiNWY5ZWZlN2NkOTQ4YWIxZDc3NTYyNzdlNDRiNmZlMTVlNzJjYzhiJmRuPVN1cGVybmF0dXJhbC5TMTFFMTIuSERUVi5YdmlELUZVTSU1QmV0dHYlNUQmdHI9dWRwJTNBJTJGJTJGdHJhY2tlci5vcGVuYml0dG9ycmVudC5jb20lM0E4MCZ0cj11ZHAlM0ElMkYlMkZvcGVuLmRlbW9uaWkuY29tJTNBMTMzNyZ0cj11ZHAlM0ElMkYlMkZ0cmFja2VyLmNvcHBlcnN1cmZlci50ayUzQTY5NjkmdHI9dWRwJTNBJTJGJTJGZXhvZHVzLmRlc3luYy5jb20lM0E2OTY5&t=Supernatural.S11E12.HDTV.XviD-FUM[ettv]&i=" target="_blank" title="Stream using Torrents-Time (Beta)"><img src="https://thepiratebay.rs/static/img/icons/icon-tt.png" alt="Stream link"/></a><a href="/user/ettv"><img src="https://thepiratebay.rs/static/img/vip.gif" alt="VIP" title="VIP" style="width:11px;" border='0'/></a><img src="https://thepiratebay.rs/static/img/11x11p.png"/>
<font class="detDesc">Uploaded 02-04&nbsp;04:33, Size 348.32&nbsp;MiB, ULed by <a class="detDesc" href="/user/ettv/" title="Browse ettv">ettv</a></font>
</td>
<td align="right">182</td>
<td align="right">18</td>
</tr>
<tr class="alt">
<td class="vertTh">
<center>
<a href="/browse/200" title="More from this category">Video</a><br/>
(<a href="/browse/205" title="More from this category">TV shows</a>)
</center>
</td>
<td>
<div class="detName"> <a href="/torrent/13422423/Supernatural.S11E12.HDTV.x264-LOL" class="detLink" title="Details for Supernatural.S11E12.HDTV.x264-LOL">Supernatural.S11E12.HDTV.x264-LOL</a>
</div>
<a href="magnet:?xt=urn:btih:d0f605b834fe6f0594ff24bc0157553f857e9038&dn=Supernatural.S11E12.HDTV.x264-LOL&tr=udp%3A//tracker.openbittorrent.com%3A80&tr=udp%3A//open.demonii.com%3A1337&tr=udp%3A//tracker.coppersurfer.tk%3A6969&tr=udp%3A//exodus.desync.com%3A6969" title="Download this torrent using magnet"><img src="https://thepiratebay.rs/static/img/icon-magnet.gif" alt="Magnet link"/></a><a href="/tt.php?tor=bWFnbmV0Oj94dD11cm46YnRpaDpkMGY2MDViODM0ZmU2ZjA1OTRmZjI0YmMwMTU3NTUzZjg1N2U5MDM4JmRuPVN1cGVybmF0dXJhbC5TMTFFMTIuSERUVi54MjY0LUxPTCZ0cj11ZHAlM0ElMkYlMkZ0cmFja2VyLm9wZW5iaXR0b3JyZW50LmNvbSUzQTgwJnRyPXVkcCUzQSUyRiUyRm9wZW4uZGVtb25paS5jb20lM0ExMzM3JnRyPXVkcCUzQSUyRiUyRnRyYWNrZXIuY29wcGVyc3VyZmVyLnRrJTNBNjk2OSZ0cj11ZHAlM0ElMkYlMkZleG9kdXMuZGVzeW5jLmNvbSUzQTY5Njk=&t=Supernatural.S11E12.HDTV.x264-LOL&i=" target="_blank" title="Stream using Torrents-Time (Beta)"><img src="https://thepiratebay.rs/static/img/icons/icon-tt.png" alt="Stream link"/></a><a href="/user/OvoJeKraj"><img src="https://thepiratebay.rs/static/img/trusted.png" alt="Trusted" title="Trusted" style="width:11px;" border='0'/></a><img src="https://thepiratebay.rs/static/img/11x11p.png"/>
<font class="detDesc">Uploaded 02-04&nbsp;04:02, Size 234.48&nbsp;MiB, ULed by <a class="detDesc" href="/user/OvoJeKraj/" title="Browse OvoJeKraj">OvoJeKraj</a></font>
</td>
<td align="right">158</td>
<td align="right">2</td>
</tr>
<tr>
<td class="vertTh">
<center>
<a href="/browse/200" title="More from this category">Video</a><br/>
(<a href="/browse/205" title="More from this category">TV shows</a>)
</center>
</td>
<td>
<div class="detName"> <a href="/torrent/13423095/Supernatural_S11E12_HDTV_AC3_DivX-HQAVI" class="detLink" title="Details for Supernatural S11E12 HDTV AC3 DivX-HQAVI">Supernatural S11E12 HDTV AC3 DivX-HQAVI</a>
</div>
<a href="magnet:?xt=urn:btih:77e977b98260a611dba728eefaf50a9dfd6a5031&dn=Supernatural+S11E12+HDTV+AC3+DivX-HQAVI&tr=udp%3A//tracker.openbittorrent.com%3A80&tr=udp%3A//open.demonii.com%3A1337&tr=udp%3A//tracker.coppersurfer.tk%3A6969&tr=udp%3A//exodus.desync.com%3A6969" title="Download this torrent using magnet"><img src="https://thepiratebay.rs/static/img/icon-magnet.gif" alt="Magnet link"/></a><a href="/tt.php?tor=bWFnbmV0Oj94dD11cm46YnRpaDo3N2U5NzdiOTgyNjBhNjExZGJhNzI4ZWVmYWY1MGE5ZGZkNmE1MDMxJmRuPVN1cGVybmF0dXJhbCtTMTFFMTIrSERUVitBQzMrRGl2WC1IUUFWSSZ0cj11ZHAlM0ElMkYlMkZ0cmFja2VyLm9wZW5iaXR0b3JyZW50LmNvbSUzQTgwJnRyPXVkcCUzQSUyRiUyRm9wZW4uZGVtb25paS5jb20lM0ExMzM3JnRyPXVkcCUzQSUyRiUyRnRyYWNrZXIuY29wcGVyc3VyZmVyLnRrJTNBNjk2OSZ0cj11ZHAlM0ElMkYlMkZleG9kdXMuZGVzeW5jLmNvbSUzQTY5Njk=&t=Supernatural S11E12 HDTV AC3 DivX-HQAVI&i=" target="_blank" title="Stream using Torrents-Time (Beta)"><img src="https://thepiratebay.rs/static/img/icons/icon-tt.png" alt="Stream link"/></a><a href="/user/teslaman"><img src="https://thepiratebay.rs/static/img/trusted.png" alt="Trusted" title="Trusted" style="width:11px;" border='0'/></a><img src="https://thepiratebay.rs/static/img/11x11p.png"/>
<font class="detDesc">Uploaded 02-04&nbsp;06:54, Size 701.01&nbsp;MiB, ULed by <a class="detDesc" href="/user/teslaman/" title="Browse teslaman">teslaman</a></font>
</td>
<td align="right">14</td>
<td align="right">3</td>
</tr>
<tr class="alt">
<td class="vertTh">
<center>
<a href="/browse/200" title="More from this category">Video</a><br/>
(<a href="/browse/205" title="More from this category">TV shows</a>)
</center>
</td>
<td>
<div class="detName"> <a href="/torrent/13425685/Supernatural_S11E12_480p_HDTV_x264_Isohunters" class="detLink" title="Details for Supernatural S11E12 480p HDTV x264 Isohunters">Supernatural S11E12 480p HDTV x264 Isohunters</a>
</div>
<a href="magnet:?xt=urn:btih:cd48cef1bcca9aa0d28c964201677f39dccda594&dn=Supernatural+S11E12+480p+HDTV+x264+Isohunters&tr=udp%3A//tracker.openbittorrent.com%3A80&tr=udp%3A//open.demonii.com%3A1337&tr=udp%3A//tracker.coppersurfer.tk%3A6969&tr=udp%3A//exodus.desync.com%3A6969" title="Download this torrent using magnet"><img src="https://thepiratebay.rs/static/img/icon-magnet.gif" alt="Magnet link"/></a><a href="/tt.php?tor=bWFnbmV0Oj94dD11cm46YnRpaDpjZDQ4Y2VmMWJjY2E5YWEwZDI4Yzk2NDIwMTY3N2YzOWRjY2RhNTk0JmRuPVN1cGVybmF0dXJhbCtTMTFFMTIrNDgwcCtIRFRWK3gyNjQrSXNvaHVudGVycyZ0cj11ZHAlM0ElMkYlMkZ0cmFja2VyLm9wZW5iaXR0b3JyZW50LmNvbSUzQTgwJnRyPXVkcCUzQSUyRiUyRm9wZW4uZGVtb25paS5jb20lM0ExMzM3JnRyPXVkcCUzQSUyRiUyRnRyYWNrZXIuY29wcGVyc3VyZmVyLnRrJTNBNjk2OSZ0cj11ZHAlM0ElMkYlMkZleG9kdXMuZGVzeW5jLmNvbSUzQTY5Njk=&t=Supernatural S11E12 480p HDTV x264 Isohunters&i=" target="_blank" title="Stream using Torrents-Time (Beta)"><img src="https://thepiratebay.rs/static/img/icons/icon-tt.png" alt="Stream link"/></a><img src="https://thepiratebay.rs/static/img/11x11p.png"/><img src="https://thepiratebay.rs/static/img/11x11p.png"/>
<font class="detDesc">Uploaded 02-04&nbsp;12:48, Size 117.49&nbsp;MiB, ULed by <a class="detDesc" href="/user/IsohuntReleaseGroup/" title="Browse IsohuntReleaseGroup">IsohuntReleaseGroup</a></font>
</td>
<td align="right">14</td>
<td align="right">0</td>
</tr>
<tr>
<td class="vertTh">
<center>
<a href="/browse/200" title="More from this category">Video</a><br/>
(<a href="/browse/205" title="More from this category">TV shows</a>)
</center>
</td>
<td>
<div class="detName"> <a href="/torrent/13422431/Supernatural.S11E12.XviD-AFG" class="detLink" title="Details for Supernatural.S11E12.XviD-AFG">Supernatural.S11E12.XviD-AFG</a>
</div>
<a href="magnet:?xt=urn:btih:ca52f60ff1e8398882746ccceadd4164719e96de&dn=Supernatural.S11E12.XviD-AFG&tr=udp%3A//tracker.openbittorrent.com%3A80&tr=udp%3A//open.demonii.com%3A1337&tr=udp%3A//tracker.coppersurfer.tk%3A6969&tr=udp%3A//exodus.desync.com%3A6969" title="Download this torrent using magnet"><img src="https://thepiratebay.rs/static/img/icon-magnet.gif" alt="Magnet link"/></a><a href="/tt.php?tor=bWFnbmV0Oj94dD11cm46YnRpaDpjYTUyZjYwZmYxZTgzOTg4ODI3NDZjY2NlYWRkNDE2NDcxOWU5NmRlJmRuPVN1cGVybmF0dXJhbC5TMTFFMTIuWHZpRC1BRkcmdHI9dWRwJTNBJTJGJTJGdHJhY2tlci5vcGVuYml0dG9ycmVudC5jb20lM0E4MCZ0cj11ZHAlM0ElMkYlMkZvcGVuLmRlbW9uaWkuY29tJTNBMTMzNyZ0cj11ZHAlM0ElMkYlMkZ0cmFja2VyLmNvcHBlcnN1cmZlci50ayUzQTY5NjkmdHI9dWRwJTNBJTJGJTJGZXhvZHVzLmRlc3luYy5jb20lM0E2OTY5&t=Supernatural.S11E12.XviD-AFG&i=" target="_blank" title="Stream using Torrents-Time (Beta)"><img src="https://thepiratebay.rs/static/img/icons/icon-tt.png" alt="Stream link"/></a><a href="/user/TvTeam"><img src="https://thepiratebay.rs/static/img/vip.gif" alt="VIP" title="VIP" style="width:11px;" border='0'/></a><img src="https://thepiratebay.rs/static/img/11x11p.png"/>
<font class="detDesc">Uploaded 02-04&nbsp;04:10, Size 338.65&nbsp;MiB, ULed by <a class="detDesc" href="/user/TvTeam/" title="Browse TvTeam">TvTeam</a></font>
</td>
<td align="right">6</td>
<td align="right">1</td>
</tr>
<tr class="alt">
<td class="vertTh">
<center>
<a href="/browse/200" title="More from this category">Video</a><br/>
(<a href="/browse/205" title="More from this category">TV shows</a>)
</center>
</td>
<td>
<div class="detName"> <a href="/torrent/13422425/Supernatural.S11E12.HDTV.x264-LOL" class="detLink" title="Details for Supernatural.S11E12.HDTV.x264-LOL">Supernatural.S11E12.HDTV.x264-LOL</a>
</div>
<a href="magnet:?xt=urn:btih:a7706092676d060f48ceb187cff38b6bedd33079&dn=Supernatural.S11E12.HDTV.x264-LOL&tr=udp%3A//tracker.openbittorrent.com%3A80&tr=udp%3A//open.demonii.com%3A1337&tr=udp%3A//tracker.coppersurfer.tk%3A6969&tr=udp%3A//exodus.desync.com%3A6969" title="Download this torrent using magnet"><img src="https://thepiratebay.rs/static/img/icon-magnet.gif" alt="Magnet link"/></a><a href="/tt.php?tor=bWFnbmV0Oj94dD11cm46YnRpaDphNzcwNjA5MjY3NmQwNjBmNDhjZWIxODdjZmYzOGI2YmVkZDMzMDc5JmRuPVN1cGVybmF0dXJhbC5TMTFFMTIuSERUVi54MjY0LUxPTCZ0cj11ZHAlM0ElMkYlMkZ0cmFja2VyLm9wZW5iaXR0b3JyZW50LmNvbSUzQTgwJnRyPXVkcCUzQSUyRiUyRm9wZW4uZGVtb25paS5jb20lM0ExMzM3JnRyPXVkcCUzQSUyRiUyRnRyYWNrZXIuY29wcGVyc3VyZmVyLnRrJTNBNjk2OSZ0cj11ZHAlM0ElMkYlMkZleG9kdXMuZGVzeW5jLmNvbSUzQTY5Njk=&t=Supernatural.S11E12.HDTV.x264-LOL&i=" target="_blank" title="Stream using Torrents-Time (Beta)"><img src="https://thepiratebay.rs/static/img/icons/icon-tt.png" alt="Stream link"/></a><a href="/user/TvTeam"><img src="https://thepiratebay.rs/static/img/vip.gif" alt="VIP" title="VIP" style="width:11px;" border='0'/></a><img src="https://thepiratebay.rs/static/img/11x11p.png"/>
<font class="detDesc">Uploaded 02-04&nbsp;04:04, Size 239.1&nbsp;MiB, ULed by <a class="detDesc" href="/user/TvTeam/" title="Browse TvTeam">TvTeam</a></font>
</td>
<td align="right">5</td>
<td align="right">1</td>
</tr>
</table>
</div>
<div align="center"></div>
<div class="ads" id="sky-banner">
</div>
</div></div></div>
<div id="foot" style="text-align:center;margin-top:1em;">
<p>
<br/>
</div>
</body>
</html>
'''

from bs4 import BeautifulSoup

soup = BeautifulSoup(data, 'html5lib')
links = soup.table.tbody.findAll('tr')

for link in links:
    columns = link.findAll('td')
    print columns[1].div.text  # name
    print columns[1].select('div + a')[0]["href"]  # magnet
    print columns[1].font.text.split(',')[1].replace('Size', '')  # size
    print columns[2].text  # seed
    print columns[3].text  # leech
    print "************************"
