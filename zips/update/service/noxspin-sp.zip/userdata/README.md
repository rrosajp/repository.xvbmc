# REPOsitory.XvBMC
 
**NOTE:** XvBMC Nederland (xbmc nl) wij zijn géén helpdesk van/voor boxverkopers
 
  
   
### XvBMC_Nederland: 
* https://bit.ly/XvBMC-NL 
* https://www.fb.com/groups/XvBMCnederland/ 
 
### XvBMC_Pi: 
* https://bit.ly/XvBMC-Pi 
* https://www.fb.com/groups/XbmcVoorBeginnersRaspberryPi/ 
 
### XvBMC_Android: 
* https://bit.ly/XvBMC-Android 
* https://www.fb.com/groups/xbmcvoorbeginners.android/ 
 
### XvBMC_FilmsSeriesMuziekSport: 
* https://bit.ly/XvBMC-Media 
* https://www.fb.com/groups/XbmcvoorbeginnersfilmsForum/ 
 
### XvBMC_retro-Games | .:C.T.R.L:. GamingRoom[NL]: 
* https://bit.ly/XvBMC-Gaming 
* https://www.fb.com/groups/ctrlgamingroom/ 
 
### XvBMC_Marktplaats: 
* https://bit.ly/XvBMC-Marktplaats 
* https://www.fb.com/groups/xbmckoopenverkoop/ 
 
### XvBMC_YouTube: 
* https://bit.ly/XvBMC-YouTube 
* https://www.youtube.com/user/onlinefilmskijken/ 
  
----------
  
*With kind regards,*
 
*Team X(v)BMC Nederland*
  
----------
  
(c) [XvBMC Nederland](https://bit.ly/XvBMC-NL) (r)