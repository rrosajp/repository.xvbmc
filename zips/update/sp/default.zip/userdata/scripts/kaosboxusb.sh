#!/bin/sh
#kodi-send -a "Notification(kaosboxusb.sh:,'$1')"
#kodi-send -a "ReloadSkin()"

myInfo(){
  TIME=3000
  if [[ "$#" == 2 ]]; then
	TIME=$(($2*1000))
  fi

  kodi-send -a "Notification(KAOSbox SD/USB:,$1,$TIME,/storage/.kodi/userdata/scripts/kaosboxusb.png)" &> /dev/null
  echo $1
}

mountUSB(){
	mkdir /storage/USB
	mount /dev/sda1 /storage/USB
}

umountUSB(){
	umount /storage/USB
	rmdir /storage/USB
}

mountSD(){
	mkdir /storage/SD
	mount /dev/mmcblk0p2 /storage/SD
}

umountSD(){
	umount /storage/SD
	rmdir /storage/SD
}

checkUSB(){
	USB=$(df | grep /dev/sda)
	if [[ "$USB" == "" ]]; then
		myInfo 'geen USB device gevonden!'
		exit
	fi
}


if [[ "$1" == "runSD" ]]; then
	myInfo 'herstarten van SD kaart' 
	mount -o remount,rw /flash
	cp /storage/.kodi/userdata/scripts/cmdlineSD.txt /flash/cmdline.txt
	sleep 1
	reboot
fi

if [[ "$1" == "runUSB" ]]; then
	checkUSB
	mountUSB
	if [ ! -d "/storage/USB/.kodi" ]; then
  		myInfo 'error: geen KODI op USB device!'
		umountUSB
		exit
	fi
	umountUSB
	myInfo 'herstarten van USB device'
	mount -o remount,rw /flash
	cp /storage/.kodi/userdata/scripts/cmdlineUSB.txt /flash/cmdline.txt
	sleep 1
	reboot
fi

if [[ "$1" == "SD2USB" ]]; then
	checkUSB
	myInfo 'Kopieer KODI van SD kaart naar USB device' 600
	mountUSB
	cd /storage/
	tar cf - . --exclude=./USB --exclude=./.kodi/userdata/Thumbnails --exclude=./.kodi/userdata/Database/Textures13.db --exclude=./.cache/ssh --exclude=./.kodi/addons/packages | ( cd './USB/'; tar xfp -)
	umountUSB
	myInfo 'KODI is gekopieerd naar USB device!'
fi


if [[ "$1" == "USB2SD" ]]; then
	checkUSB
	myInfo 'kopieer KODI van USB device naar SD kaart' 600
	mountSD
	cd /storage/
	tar cf - . --exclude=./SD --exclude=./.kodi/userdata/Thumbnails --exclude=./.kodi/userdata/Database/Textures13.db --exclude=./.cache/ssh --exclude=./.kodi/addons/packages | ( cd './SD/'; tar xfp -)
	umountSD
	myInfo 'KODI is gekopieerd naar SD kaart!'
fi



if [[ "$1" == "USBext" ]]; then
	checkUSB
	myInfo 'formateren USB voor KODI (ext4)' 60
	umount /dev/sda1 &> /dev/null
	umount /dev/sda2 &> /dev/null
#	sleep 1
#	parted -s /dev/sda rm 1 rm 2
	dd if=/dev/zero of=/dev/sda bs=1M count=10 &> /dev/null
	parted /dev/sda mklabel msdos
	parted -s -a optimal /dev/sda mkpart primary ext4 1 100% &> /dev/null
	mkfs.ext4 -L "KB KODI" /dev/sda1 
	eject /dev/sda
	sleep 1
	eject -t /dev/sda
	myInfo 'USB device is geformateerd voor KODI!'
fi

if [[ "$1" == "standaard" ]]; then
	myInfo 'Standaard Config' 
	mount -o remount,rw /flash
	cp /storage/.kodi/userdata/scripts/configSTABLE.txt /flash/config.txt
	cp /storage/.kodi/userdata/scripts/oemsplash.png /flash/oemsplash.png
	sleep 1
	reboot
fi

if [[ "$1" == "max" ]]; then
	myInfo 'MAX Config' 
	mount -o remount,rw /flash
	cp /storage/.kodi/userdata/scripts/configMAX.txt /flash/config.txt
        cp /storage/.kodi/userdata/scripts/oemsplash.png /flash/oemsplash.png
	sleep 1
	reboot
fi


if [[ "$1" == "standaard3" ]]; then
	myInfo 'Standaard Config' 
	mount -o remount,rw /flash
	cp /storage/.kodi/userdata/scripts/configSTABLE3.txt /flash/config.txt
	cp /storage/.kodi/userdata/scripts/oemsplash.png /flash/oemsplash.png
	sleep 1
	reboot
fi

if [[ "$1" == "max3" ]]; then
	myInfo 'MAX Config' 
	mount -o remount,rw /flash
	cp /storage/.kodi/userdata/scripts/configMAX3.txt /flash/config.txt
	cp /storage/.kodi/userdata/scripts/oemsplash.png /flash/oemsplash.png
	sleep 1
	reboot
fi


if [[ "$1" == "standaardadvanced" ]]; then
	myInfo 'Standaard advancedsettings' 
	cp /storage/.kodi/userdata/advancedsettingsSTANDAARD.xml /storage/.kodi/userdata/advancedsettings.xml
	sleep 1
	reboot
fi

if [[ "$1" == "nuladvanced" ]]; then
	myInfo 'Zero cache advancedsettings' 
	cp /storage/.kodi/userdata/advancedsettingsZERO.xml /storage/.kodi/userdata/advancedsettings.xml
	sleep 1
	reboot
fi