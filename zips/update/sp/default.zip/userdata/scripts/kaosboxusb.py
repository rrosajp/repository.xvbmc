#!/usr/bin/env python
import os, sys
#~ import os, sys, xbmc, xbmcgui
#xbmc.executebuiltin('Notification(kaosboxusb.py:,'+sys.argv[1]+')')

bashCommand = "/bin/bash /storage/.kodi/userdata/scripts/kaosboxusb.sh "+sys.argv[1]
#xbmc.executebuiltin('Notification(kaosboxusb.py:,'+bashCommand+')')
os.system(bashCommand)

#~ parameter=sys.argv[1];
#~ if parameter=="runSD":
	#~ xbmc.executebuiltin('Notification(runSD,go)');
	#~ xbmc.executebuiltin('Skin.SetString(LiveTVHomeItem.Disable,)')
	#~ xbmc.executebuiltin('Skin.ToggleSetting(lowermainmenu)')
#~ elif parameter=="runUSB":
	#~ xbmc.executebuiltin('Notification(runUSB,go)');

#~ xbmc.executebuiltin('ReloadSkin()')
