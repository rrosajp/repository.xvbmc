OpenELEC RPi Config
=============================

Unofficial Raspberry Pi configuration add-on for OpenELEC.
