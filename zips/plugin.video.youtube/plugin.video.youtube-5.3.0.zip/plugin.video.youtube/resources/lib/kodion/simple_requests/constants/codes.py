__author__ = 'bromix'

ok = 200

unauthorized = 401