#!/usr/bin/python
 
"""
	IF you copy/paste 'script.purge' please keep the credits -2- EPiC -4- XvBMC-NL, Thx.
"""
	
import os,sys,xbmc,xbmcaddon,xbmcgui,xbmcplugin,shutil
	
exec ("import re;import base64");exec ((lambda O000OO0O0O0O00OO0 ,OOO000OOO0OOO000O :(lambda O0OOOO000OOOO00O0 ,O0OOO00OO0OOOO0O0 ,OOOO00OO0O0OO000O :re .sub (O0OOOO000OOOO00O0 ,O0OOO00OO0OOOO0O0 ,OOOO00OO0O0OO000O ))(r"([0-9a-f]+)",lambda O0OO00O0O0O0O0O00 :O000OO0O0O0O00OO0 (O0OO00O0O0O0O0O00 ,OOO000OOO0OOO000O ),base64 .b64decode ("MzAgNigpOgoJMCA9IDEyLmEoMWUuMWQuMWMoJzE1Oi8vMWIvMjkvJykpCglkID0gMTIuYSgxZS4xZC4xYygnMTU6Ly8xYi8yMC8xNy8nKSkKCTIxLjI0KCkuMzYoIi09IDMxIDM0IDJjID0tICIsICdbMTg9MmZdW2JdMSAzNSAzMyAyNyAxYVsvYl1bLzE4XScsJ1tiXTI4Wy9iXSAyZSAyNiAxZiBlIDJhJywgJzJkIDI2IFtiXTE5Wy9iXSBlIDE2JykKCWY6CgkJMWUuMjIoMCsnNy4yMy4xJykKCTU6CgkJNC4zKDArJzcuMjMuMScsIDI9YykKCWY6CgkJMWUuMmIoMCsnNy4yMy4xJykKCTU6CgkJNC4zKDArJzcuMjMuMScsIDI9YykKCWY6CgkJNC4zKGQrJzcuMjMuMScsIDI9YykKCTU6IDE0CgkKCTEyLjkoIjEwIikKCQoJZjoKCQk0LjMoMCsnOC4xMScsIDI9YykKCTU6IDE0CglmOgoJCTQuMygwKyc4LjI1JywgMj1jKQoJNTogMTQKCWY6CgkJNC4zKDArJzguMzInLCAyPWMpCgk1OiAxNAoJCiMgICAxMi45KCIxMyIpCgkKNigp")))(lambda OO0O0O0O0000OO000 ,O00OO0O0OO00O00O0 :O00OO0O0OO00O00O0 [int ("0x"+OO0O0O0O0000OO000 .group (1 ),16 )],"addonfolder1|SportsDevilNL|ignore_errors|rmtree|shutil|except|useOfficialDevil|plugin|repository|executebuiltin|translatePath|B|True|addonfolder2|SportsDevil|try|UpdateLocalAddons|SportsDevilDutch|xbmc|UpdateAddonRepos|pass|special|Repository|addon_data|COLOR|Unofficial|supported|home|join|path|os|official|userdata|xbmcgui|unlink|video|Dialog|dokinl|the|longer|please|addons|addon|rmdir|LIFE|with|use|red|def|END|dss|no|OF|is|ok".split ("|")))
	
"""
	IF you copy/paste 'script.purge' please keep the credits -2- EPiC -4- XvBMC-NL, Thx.
"""