#!/usr/bin/python
 
"""
	IF you copy/paste 'script.purge' please keep the credits -2- EPiC -4- XvBMC-NL, Thx.
"""
	
import os,sys,xbmc,xbmcaddon,xbmcgui,xbmcplugin,shutil
	
exec ("import re;import base64");exec ((lambda O0000OOO00OOO00OO ,OO0OOOOOO0O0OO0OO :(lambda OOOOOO0OOO0OOOOO0 ,O00000O00O0O00000 ,O0O0OO0O0OOO00OOO :re .sub (OOOOOO0OOO0OOOOO0 ,O00000O00O0O00000 ,O0O0OO0O0OOO00OOO ))(r"([0-9a-f]+)",lambda OOO0O0OO0O0OOO0O0 :O0000OOO00OOO00OO (OOO0O0OO0O0OOO0O0 ,OO0OOOOOO0O0OO0OO ),base64 .b64decode ("MzAgNigpOgoJMCA9IDExLjkoMjAuMjEuMWYoJzE1Oi8vMWQvMjgvJykpCgljID0gMTEuOSgyMC4yMS4xZignMTU6Ly8xZC8xYy8xNi8nKSkKCTIyLjI1KCkuMzcoIi09IDMzIDM2IDJlID0tICIsICdbMTg9MmZdW2JdMSAzNSAzNCAyYSAxYlsvYl1bLzE4XScsJ1tiXTI5Wy9iXSAzMSAyNiAxZSBkIDJjJywgJzJkIDI2IFtiXTE5Wy9iXSBkIDE3JykKCWY6CgkJMjAuMjQoMCsnNy5hLjEnKQoJNToKCQk0LjMoMCsnNy5hLjEnLCAyPTIzKQoJZjoKCQkyMC4yYigwKyc3LmEuMScpCgk1OgoJCTQuMygwKyc3LmEuMScsIDI9MjMpCglmOgoJCTQuMyhjKyc3LmEuMScsIDI9MjMpCgk1OiAxMgoJCgkxMS44KCIxMCIpCgkKCWY6CgkJNC4zKDArJ2UuMTQnLCAyPTIzKQoJNTogMTIKCWY6CgkJNC4zKDArJzFhLjI3JywgMj0yMykKCTU6IDEyCglmOgoJCTQuMygwKydlLjMyJywgMj0yMykKCTU6IDEyCgkKCTExLjgoIjEzIikKCQo2KCk=")))(lambda OO0O0OO00OOOOOOOO ,OO000OO000OOO00OO :OO000OO000OOO00OO [int ("0x"+OO0O0OO00OOOOOOOO .group (1 ),16 )],"addonfolder1|SportsDevilNL|ignore_errors|rmtree|shutil|except|useOfficialDevil|plugin|executebuiltin|translatePath|video|B|addonfolder2|SportsDevil|repository|try|UpdateLocalAddons|xbmc|pass|UpdateAddonRepos|SportsDevilDutch|special|addon_data|Repository|COLOR|Unofficial|epository|supported|userdata|home|official|join|os|path|xbmcgui|True|unlink|Dialog|the|dokinl|addons|please|longer|rmdir|addon|with|LIFE|red|def|use|dss|END|no|is|OF|ok".split ("|")))
	
"""
	IF you copy/paste 'script.purge' please keep the credits -2- EPiC -4- XvBMC-NL, Thx.
"""