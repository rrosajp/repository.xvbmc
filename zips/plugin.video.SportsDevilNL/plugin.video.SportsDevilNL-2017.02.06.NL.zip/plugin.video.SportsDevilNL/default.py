#!/usr/bin/python
	
"""
	IF you copy/paste 'script.purge' please keep the credits -2- EPiC -4- XvBMC-NL, Thx.
"""
	
import base64,os,sys,xbmc,xbmcaddon,xbmcgui,xbmcplugin,re,shutil
	
exec ((lambda OOOOO0OO000000OO0 ,OO0O0OO000O00O00O :(lambda O00O00O00O0O00000 ,OOO0O00OOO0OO0OOO ,O0OOOOO0000OO000O :re .sub (O00O00O00O0O00000 ,OOO0O00OOO0OO0OOO ,O0OOOOO0000OO000O ))(r"([0-9a-f]+)",lambda O00OOOO0O0O0O00OO :OOOOO0OO000000OO0 (O00OOOO0O0O0O00OO ,OO0O0OO000O00O00O ),base64 .b64decode ("M2MgNigpOgoJMCA9IDE1LmEoMjAuMjYuMWYoJzE4Oi8vMjIvMmYvJykpCgljID0gMTUuYSgyMC4yNi4xZignMTg6Ly8yMi8yMS8xYi8nKSkKCTI5LjJjKCkuNDMoIlsxYT0zZF1lW2JdNDRbL2JdIDQxIDQ1IDJkIDFlWy8xYV0iLCAnW2JdMjQgZSAoNDApIDMzICsgMWMgMzk6Wy9iXScsJzM2Oi8vMjcuM2YvMzgtMTktMjUtMjgtMzIvJywgJy4uLjQyIGYgM2UgMjUtMmIgMzc6IDM1Oi8vMmEuM2IvMjMvNy4zNC8nKQoJZjoKCQkyMC4zMCgwKyc4LjNhLjInKQoJNDoKCQk1LjMoMCsnOC4zYS4yJywgMT1kKQoJZjoKCQkyMC4zMSgwKyc4LjNhLjInKQoJNDoKCQk1LjMoMCsnOC4zYS4yJywgMT1kKQoJZjoKCQk1LjMoYysnOC4zYS4yJywgMT1kKQoJNDogMTMKCQoJMTUuOSgiMTIiKQoJCglmOgoJCTUuMygwKyc3LjE2JywgMT1kKQoJNDogMTMKIyAgIGY6CiMJICAgNS4zKDArJzcuMTAnLCAxPWQpCiMgICA0OiAxMwoJZjoKCQkxND0yZS4xZCgnMTE9JykKCQk1LjMoMCsxNCwgMT1kKQoJNDogMTMKCQoJIzE1LjkoIjE3IikKCQo2KCk=")))(lambda O0OOO00OO0OOOOOOO ,OO00OO00O0OO0O0O0 :OO00OO00O0OO0O0O0 [int ("0x"+O0OOO00OO0OOOOOOO .group (1 ),16 )],"addonfolder1|ignore_errors|SportsDevilNL|rmtree|except|shutil|useOfficialDevil|repository|plugin|executebuiltin|translatePath|B|addonfolder2|True|SportsDevil|try|groetjesaanokidokinl|cmVwb3NpdG9yeS5kc3M|UpdateLocalAddons|pass|clean1st|xbmc|SportsDevilDutch|UpdateAddonRepos|special|sportsdevil|COLOR|addon_data|Unofficial|b64decode|supported|join|os|userdata|home|download|Official|repo|path|koditips|install|xbmcgui|archive|mirror|Dialog|longer|base64|addons|unlink|rmdir|guide|addon|xvbmc|https|http|from|kodi|Repo|video|org|def|red|our|com|US|is|or|ok|NL|no".split ("|")))
	
"""
	IF you copy/paste 'script.purge' please keep the credits -2- EPiC -4- XvBMC-NL, Thx.
"""