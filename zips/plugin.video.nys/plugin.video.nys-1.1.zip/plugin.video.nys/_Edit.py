import xbmcaddon

MainBase = 'http://bit.ly/NYSNYSNYS'
addon = xbmcaddon.Addon('plugin.video.nys')
