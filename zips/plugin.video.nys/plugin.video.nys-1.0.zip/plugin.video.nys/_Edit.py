import xbmcaddon

MainBase = 'http://bit.ly/2qvQYjq'
addon = xbmcaddon.Addon('plugin.video.nys')
